#ifndef DEFINES_LVO_DOPUS_H
#define DEFINES_LVO_DOPUS_H

/*
    *** Automatically generated from '/home/vsts/work/1/s/contrib/dopus/Library/dopus.conf'. Edits will be lost. ***
    Copyright (C) 1995-2025, The AROS Development Team. All rights reserved.
*/

/*
    Desc: Function LVO's for dopus
*/

#define LVOFileRequest          5
#define LVODo3DBox          6
#define LVODo3DStringBox          7
#define LVODo3DCycleBox          8
#define LVODoArrow          9
#define LVOLCreateExtIO          11
#define LVOLCreatePort          12
#define LVOLDeleteExtIO          13
#define LVOLDeletePort          14
#define LVOLToUpper          15
#define LVOLToLower          16
#define LVOLStrCat          17
#define LVOLStrnCat          18
#define LVOLStrCpy          19
#define LVOLStrnCpy          20
#define LVOLStrCmp          21
#define LVOLStrnCmp          22
#define LVOLStrCmpI          23
#define LVOLStrnCmpI          24
#define LVOStrCombine          25
#define LVOStrConcat          26
#define LVOLParsePattern          27
#define LVOLMatchPattern          28
#define LVOLParsePatternI          29
#define LVOLMatchPatternI          30
#define LVOBtoCStr          31
#define LVOAssign          32
#define LVOBaseName          33
#define LVOCompareLock          34
#define LVOPathName          35
#define LVOSendPacket          36
#define LVOTackOn          37
#define LVOStampToStr          38
#define LVOStrToStamp          39
#define LVOAddListView          40
#define LVOListViewIDCMP          41
#define LVORefreshListView          42
#define LVORemoveListView          43
#define LVODrawCheckMark          44
#define LVOFixSliderBody          45
#define LVOFixSliderPot          46
#define LVOGetSliderPos          47
#define LVOLAllocRemember          48
#define LVOLFreeRemember          49
#define LVOSetBusyPointer          50
#define LVOGetWBScreen          51
#define LVOSearchPathList          52
#define LVOCheckExist          53
#define LVOCompareDate          54
#define LVOSeed          55
#define LVORandom          56
#define LVOStrToUpper          57
#define LVOStrToLower          58
#define LVORawkeyToStr          59
#define LVODoRMBGadget          60
#define LVOAddGadgets          61
#define LVOActivateStrGad          62
#define LVORefreshStrGad          63
#define LVOCheckNumGad          64
#define LVOCheckHexGad          65
#define LVOAtoh          66
#define LVOHiliteGad          67
#define LVODoSimpleRequest          68
#define LVOReadConfig          69
#define LVOSaveConfig          70
#define LVODefaultConfig          71
#define LVOGetDevices          72
#define LVOAssignGadget          73
#define LVOAssignMenu          74
#define LVOFindSystemFile          75
#define LVODo3DFrame          76
#define LVOFreeConfig          77
#define LVODoCycleGadget          78
#define LVOUScoreText          79
#define LVODisableGadget          80
#define LVOEnableGadget          81
#define LVOGhostGadget          82
#define LVODrawRadioButton          83
#define LVOGetButtonImage          84
#define LVOShowSlider          85
#define LVOCheckConfig          86
#define LVOGetCheckImage          87
#define LVOOpenRequester          88
#define LVOCloseRequester          89
#define LVOAddRequesterObject          90
#define LVORefreshRequesterObject          91
#define LVOObjectText          92
#define LVODoGlassImage          93
#define LVODecode_RLE          94
#define LVOReadStringFile          95
#define LVOFreeStringFile          96
#define LVOLFreeRemEntry          97
#define LVOAddGadgetBorders          98
#define LVOCreateGadgetBorders          99
#define LVOSelectGadget          100
#define LVOFSSetMenuStrip          101

#endif /* DEFINES_LVO_DOPUS_H*/
