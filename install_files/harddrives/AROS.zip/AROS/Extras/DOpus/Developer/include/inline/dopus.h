#ifndef INLINE_DOPUS_H
#define INLINE_DOPUS_H

/*
    *** Automatically generated from '/home/vsts/work/1/s/contrib/dopus/Library/dopus.conf'. Edits will be lost. ***
    Copyright (C) 1995-2025, The AROS Development Team. All rights reserved.
*/

/*
    Desc: Inline function(s) for dopus
*/

#include <aros/libcall.h>
#include <exec/types.h>
#include <aros/symbolsets.h>
#include <aros/preprocessor/variadic/cast2iptr.hpp>

#if !defined(__DOPUS_LIBBASE)
#    define __DOPUS_LIBBASE DOpusBase
#endif


#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_FileRequest(struct DOpusFileReq* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC1(int, FileRequest,
        AROS_LCA(struct DOpusFileReq*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 5, DOpus    );
}

#define FileRequest(arg1) \
    __inline_DOpus_FileRequest((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_Do3DBox(struct RastPort* __arg1, int __arg2, int __arg3, int __arg4, int __arg5, int __arg6, int __arg7, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC7NR(void, Do3DBox,
        AROS_LCA(struct RastPort*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        AROS_LCA(int,(__arg3),D1),
        AROS_LCA(int,(__arg4),D2),
        AROS_LCA(int,(__arg5),D3),
        AROS_LCA(int,(__arg6),D4),
        AROS_LCA(int,(__arg7),D5),
        struct DOpusBase *, (__DOpusBase), 6, DOpus    );
}

#define Do3DBox(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __inline_DOpus_Do3DBox((arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_Do3DStringBox(struct RastPort* __arg1, int __arg2, int __arg3, int __arg4, int __arg5, int __arg6, int __arg7, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC7NR(void, Do3DStringBox,
        AROS_LCA(struct RastPort*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        AROS_LCA(int,(__arg3),D1),
        AROS_LCA(int,(__arg4),D2),
        AROS_LCA(int,(__arg5),D3),
        AROS_LCA(int,(__arg6),D4),
        AROS_LCA(int,(__arg7),D5),
        struct DOpusBase *, (__DOpusBase), 7, DOpus    );
}

#define Do3DStringBox(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __inline_DOpus_Do3DStringBox((arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_Do3DCycleBox(struct RastPort* __arg1, int __arg2, int __arg3, int __arg4, int __arg5, int __arg6, int __arg7, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC7NR(void, Do3DCycleBox,
        AROS_LCA(struct RastPort*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        AROS_LCA(int,(__arg3),D1),
        AROS_LCA(int,(__arg4),D2),
        AROS_LCA(int,(__arg5),D3),
        AROS_LCA(int,(__arg6),D4),
        AROS_LCA(int,(__arg7),D5),
        struct DOpusBase *, (__DOpusBase), 8, DOpus    );
}

#define Do3DCycleBox(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __inline_DOpus_Do3DCycleBox((arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_DoArrow(struct RastPort* __arg1, int __arg2, int __arg3, int __arg4, int __arg5, int __arg6, int __arg7, int __arg8, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC8NR(void, DoArrow,
        AROS_LCA(struct RastPort*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        AROS_LCA(int,(__arg3),D1),
        AROS_LCA(int,(__arg4),D2),
        AROS_LCA(int,(__arg5),D3),
        AROS_LCA(int,(__arg6),D4),
        AROS_LCA(int,(__arg7),D5),
        AROS_LCA(int,(__arg8),D6),
        struct DOpusBase *, (__DOpusBase), 9, DOpus    );
}

#define DoArrow(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) \
    __inline_DOpus_DoArrow((arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), (arg8), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline struct IORequest* __inline_DOpus_LCreateExtIO(struct MsgPort* __arg1, int __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(struct IORequest*, LCreateExtIO,
        AROS_LCA(struct MsgPort*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        struct DOpusBase *, (__DOpusBase), 11, DOpus    );
}

#define LCreateExtIO(arg1, arg2) \
    __inline_DOpus_LCreateExtIO((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline struct MsgPort* __inline_DOpus_LCreatePort(char* __arg1, int __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(struct MsgPort*, LCreatePort,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        struct DOpusBase *, (__DOpusBase), 12, DOpus    );
}

#define LCreatePort(arg1, arg2) \
    __inline_DOpus_LCreatePort((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_LDeleteExtIO(struct IORequest* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC1NR(void, LDeleteExtIO,
        AROS_LCA(struct IORequest*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 13, DOpus    );
}

#define LDeleteExtIO(arg1) \
    __inline_DOpus_LDeleteExtIO((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_LDeletePort(struct MsgPort* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC1NR(void, LDeletePort,
        AROS_LCA(struct MsgPort*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 14, DOpus    );
}

#define LDeletePort(arg1) \
    __inline_DOpus_LDeletePort((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline char __inline_DOpus_LToUpper(char __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC1(char, LToUpper,
        AROS_LCA(char,(__arg1),D0),
        struct DOpusBase *, (__DOpusBase), 15, DOpus    );
}

#define LToUpper(arg1) \
    __inline_DOpus_LToUpper((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline char __inline_DOpus_LToLower(char __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC1(char, LToLower,
        AROS_LCA(char,(__arg1),D0),
        struct DOpusBase *, (__DOpusBase), 16, DOpus    );
}

#define LToLower(arg1) \
    __inline_DOpus_LToLower((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_LStrCat(char* __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, LStrCat,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 17, DOpus    );
}

#define LStrCat(arg1, arg2) \
    __inline_DOpus_LStrCat((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_LStrnCat(char* __arg1, char* __arg2, int __arg3, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC3NR(void, LStrnCat,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        struct DOpusBase *, (__DOpusBase), 18, DOpus    );
}

#define LStrnCat(arg1, arg2, arg3) \
    __inline_DOpus_LStrnCat((arg1), (arg2), (arg3), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_LStrCpy(char* __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, LStrCpy,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 19, DOpus    );
}

#define LStrCpy(arg1, arg2) \
    __inline_DOpus_LStrCpy((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_LStrnCpy(char* __arg1, char* __arg2, int __arg3, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC3NR(void, LStrnCpy,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        struct DOpusBase *, (__DOpusBase), 20, DOpus    );
}

#define LStrnCpy(arg1, arg2, arg3) \
    __inline_DOpus_LStrnCpy((arg1), (arg2), (arg3), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_LStrCmp(char* __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, LStrCmp,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 21, DOpus    );
}

#define LStrCmp(arg1, arg2) \
    __inline_DOpus_LStrCmp((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_LStrnCmp(char* __arg1, char* __arg2, int __arg3, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC3(int, LStrnCmp,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        struct DOpusBase *, (__DOpusBase), 22, DOpus    );
}

#define LStrnCmp(arg1, arg2, arg3) \
    __inline_DOpus_LStrnCmp((arg1), (arg2), (arg3), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_LStrCmpI(char* __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, LStrCmpI,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 23, DOpus    );
}

#define LStrCmpI(arg1, arg2) \
    __inline_DOpus_LStrCmpI((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_LStrnCmpI(char* __arg1, char* __arg2, int __arg3, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC3(int, LStrnCmpI,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        struct DOpusBase *, (__DOpusBase), 24, DOpus    );
}

#define LStrnCmpI(arg1, arg2, arg3) \
    __inline_DOpus_LStrnCmpI((arg1), (arg2), (arg3), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_StrCombine(char* __arg1, char* __arg2, char* __arg3, int __arg4, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC4(int, StrCombine,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(char*,(__arg3),A2),
        AROS_LCA(int,(__arg4),D0),
        struct DOpusBase *, (__DOpusBase), 25, DOpus    );
}

#define StrCombine(arg1, arg2, arg3, arg4) \
    __inline_DOpus_StrCombine((arg1), (arg2), (arg3), (arg4), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_StrConcat(char* __arg1, char* __arg2, int __arg3, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC3(int, StrConcat,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        struct DOpusBase *, (__DOpusBase), 26, DOpus    );
}

#define StrConcat(arg1, arg2, arg3) \
    __inline_DOpus_StrConcat((arg1), (arg2), (arg3), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_LParsePattern(char* __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, LParsePattern,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 27, DOpus    );
}

#define LParsePattern(arg1, arg2) \
    __inline_DOpus_LParsePattern((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_LMatchPattern(char* __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, LMatchPattern,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 28, DOpus    );
}

#define LMatchPattern(arg1, arg2) \
    __inline_DOpus_LMatchPattern((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_LParsePatternI(char* __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, LParsePatternI,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 29, DOpus    );
}

#define LParsePatternI(arg1, arg2) \
    __inline_DOpus_LParsePatternI((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_LMatchPatternI(char* __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, LMatchPatternI,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 30, DOpus    );
}

#define LMatchPatternI(arg1, arg2) \
    __inline_DOpus_LMatchPatternI((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_BtoCStr(BSTR __arg1, char* __arg2, int __arg3, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC3NR(void, BtoCStr,
        AROS_LCA(BSTR,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        struct DOpusBase *, (__DOpusBase), 31, DOpus    );
}

#define BtoCStr(arg1, arg2, arg3) \
    __inline_DOpus_BtoCStr((arg1), (arg2), (arg3), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_Assign(char* __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, Assign,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 32, DOpus    );
}

#define Assign(arg1, arg2) \
    __inline_DOpus_Assign((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline char* __inline_DOpus_BaseName(char* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC1(char*, BaseName,
        AROS_LCA(char*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 33, DOpus    );
}

#define BaseName(arg1) \
    __inline_DOpus_BaseName((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_CompareLock(BPTR __arg1, BPTR __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, CompareLock,
        AROS_LCA(BPTR,(__arg1),A0),
        AROS_LCA(BPTR,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 34, DOpus    );
}

#define CompareLock(arg1, arg2) \
    __inline_DOpus_CompareLock((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_PathName(BPTR __arg1, char* __arg2, int __arg3, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC3(int, PathName,
        AROS_LCA(BPTR,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        struct DOpusBase *, (__DOpusBase), 35, DOpus    );
}

#define PathName(arg1, arg2, arg3) \
    __inline_DOpus_PathName((arg1), (arg2), (arg3), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_SendPacket(struct MsgPort* __arg1, int __arg2, IPTR* __arg3, int __arg4, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC4(int, SendPacket,
        AROS_LCA(struct MsgPort*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        AROS_LCA(IPTR*,(__arg3),A1),
        AROS_LCA(int,(__arg4),D1),
        struct DOpusBase *, (__DOpusBase), 36, DOpus    );
}

#define SendPacket(arg1, arg2, arg3, arg4) \
    __inline_DOpus_SendPacket((arg1), (arg2), (arg3), (arg4), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_TackOn(char* __arg1, char* __arg2, int __arg3, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC3(int, TackOn,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        struct DOpusBase *, (__DOpusBase), 37, DOpus    );
}

#define TackOn(arg1, arg2, arg3) \
    __inline_DOpus_TackOn((arg1), (arg2), (arg3), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_StampToStr(struct DOpusDateTime* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC1(int, StampToStr,
        AROS_LCA(struct DOpusDateTime*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 38, DOpus    );
}

#define StampToStr(arg1) \
    __inline_DOpus_StampToStr((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_StrToStamp(struct DOpusDateTime* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC1(int, StrToStamp,
        AROS_LCA(struct DOpusDateTime*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 39, DOpus    );
}

#define StrToStamp(arg1) \
    __inline_DOpus_StrToStamp((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_AddListView(struct DOpusListView* __arg1, int __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, AddListView,
        AROS_LCA(struct DOpusListView*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        struct DOpusBase *, (__DOpusBase), 40, DOpus    );
}

#define AddListView(arg1, arg2) \
    __inline_DOpus_AddListView((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline struct DOpusListView* __inline_DOpus_ListViewIDCMP(struct DOpusListView* __arg1, struct IntuiMessage* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(struct DOpusListView*, ListViewIDCMP,
        AROS_LCA(struct DOpusListView*,(__arg1),A0),
        AROS_LCA(struct IntuiMessage*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 41, DOpus    );
}

#define ListViewIDCMP(arg1, arg2) \
    __inline_DOpus_ListViewIDCMP((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_RefreshListView(struct DOpusListView* __arg1, int __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, RefreshListView,
        AROS_LCA(struct DOpusListView*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        struct DOpusBase *, (__DOpusBase), 42, DOpus    );
}

#define RefreshListView(arg1, arg2) \
    __inline_DOpus_RefreshListView((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_RemoveListView(struct DOpusListView* __arg1, int __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, RemoveListView,
        AROS_LCA(struct DOpusListView*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        struct DOpusBase *, (__DOpusBase), 43, DOpus    );
}

#define RemoveListView(arg1, arg2) \
    __inline_DOpus_RemoveListView((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_DrawCheckMark(struct RastPort* __arg1, int __arg2, int __arg3, int __arg4, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC4NR(void, DrawCheckMark,
        AROS_LCA(struct RastPort*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        AROS_LCA(int,(__arg3),D1),
        AROS_LCA(int,(__arg4),D2),
        struct DOpusBase *, (__DOpusBase), 44, DOpus    );
}

#define DrawCheckMark(arg1, arg2, arg3, arg4) \
    __inline_DOpus_DrawCheckMark((arg1), (arg2), (arg3), (arg4), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_FixSliderBody(struct Window* __arg1, struct Gadget* __arg2, int __arg3, int __arg4, int __arg5, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC5NR(void, FixSliderBody,
        AROS_LCA(struct Window*,(__arg1),A0),
        AROS_LCA(struct Gadget*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        AROS_LCA(int,(__arg4),D1),
        AROS_LCA(int,(__arg5),D2),
        struct DOpusBase *, (__DOpusBase), 45, DOpus    );
}

#define FixSliderBody(arg1, arg2, arg3, arg4, arg5) \
    __inline_DOpus_FixSliderBody((arg1), (arg2), (arg3), (arg4), (arg5), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_FixSliderPot(struct Window* __arg1, struct Gadget* __arg2, int __arg3, int __arg4, int __arg5, int __arg6, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC6NR(void, FixSliderPot,
        AROS_LCA(struct Window*,(__arg1),A0),
        AROS_LCA(struct Gadget*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        AROS_LCA(int,(__arg4),D1),
        AROS_LCA(int,(__arg5),D2),
        AROS_LCA(int,(__arg6),D3),
        struct DOpusBase *, (__DOpusBase), 46, DOpus    );
}

#define FixSliderPot(arg1, arg2, arg3, arg4, arg5, arg6) \
    __inline_DOpus_FixSliderPot((arg1), (arg2), (arg3), (arg4), (arg5), (arg6), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_GetSliderPos(struct Gadget* __arg1, int __arg2, int __arg3, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC3(int, GetSliderPos,
        AROS_LCA(struct Gadget*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        AROS_LCA(int,(__arg3),D1),
        struct DOpusBase *, (__DOpusBase), 47, DOpus    );
}

#define GetSliderPos(arg1, arg2, arg3) \
    __inline_DOpus_GetSliderPos((arg1), (arg2), (arg3), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void* __inline_DOpus_LAllocRemember(struct DOpusRemember** __arg1, ULONG __arg2, ULONG __arg3, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC3(void*, LAllocRemember,
        AROS_LCA(struct DOpusRemember**,(__arg1),A0),
        AROS_LCA(ULONG,(__arg2),D0),
        AROS_LCA(ULONG,(__arg3),D1),
        struct DOpusBase *, (__DOpusBase), 48, DOpus    );
}

#define LAllocRemember(arg1, arg2, arg3) \
    __inline_DOpus_LAllocRemember((arg1), (arg2), (arg3), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_LFreeRemember(struct DOpusRemember** __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC1NR(void, LFreeRemember,
        AROS_LCA(struct DOpusRemember**,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 49, DOpus    );
}

#define LFreeRemember(arg1) \
    __inline_DOpus_LFreeRemember((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_SetBusyPointer(struct Window* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC1NR(void, SetBusyPointer,
        AROS_LCA(struct Window*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 50, DOpus    );
}

#define SetBusyPointer(arg1) \
    __inline_DOpus_SetBusyPointer((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_GetWBScreen(struct Screen* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC1NR(void, GetWBScreen,
        AROS_LCA(struct Screen*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 51, DOpus    );
}

#define GetWBScreen(arg1) \
    __inline_DOpus_GetWBScreen((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_SearchPathList(char* __arg1, char* __arg2, int __arg3, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC3(int, SearchPathList,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        struct DOpusBase *, (__DOpusBase), 52, DOpus    );
}

#define SearchPathList(arg1, arg2, arg3) \
    __inline_DOpus_SearchPathList((arg1), (arg2), (arg3), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_CheckExist(char* __arg1, int* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, CheckExist,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(int*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 53, DOpus    );
}

#define CheckExist(arg1, arg2) \
    __inline_DOpus_CheckExist((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_CompareDate(struct DateStamp* __arg1, struct DateStamp* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, CompareDate,
        AROS_LCA(struct DateStamp*,(__arg1),A0),
        AROS_LCA(struct DateStamp*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 54, DOpus    );
}

#define CompareDate(arg1, arg2) \
    __inline_DOpus_CompareDate((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_Seed(int __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC1NR(void, Seed,
        AROS_LCA(int,(__arg1),D0),
        struct DOpusBase *, (__DOpusBase), 55, DOpus    );
}

#define Seed(arg1) \
    __inline_DOpus_Seed((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_Random(int __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC1(int, Random,
        AROS_LCA(int,(__arg1),D0),
        struct DOpusBase *, (__DOpusBase), 56, DOpus    );
}

#define Random(arg1) \
    __inline_DOpus_Random((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_StrToUpper(char* __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, StrToUpper,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 57, DOpus    );
}

#define StrToUpper(arg1, arg2) \
    __inline_DOpus_StrToUpper((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_StrToLower(char* __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, StrToLower,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 58, DOpus    );
}

#define StrToLower(arg1, arg2) \
    __inline_DOpus_StrToLower((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_RawkeyToStr(UWORD __arg1, UWORD __arg2, char* __arg3, char* __arg4, int __arg5, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC5(int, RawkeyToStr,
        AROS_LCA(UWORD,(__arg1),D0),
        AROS_LCA(UWORD,(__arg2),D1),
        AROS_LCA(char*,(__arg3),A0),
        AROS_LCA(char*,(__arg4),A1),
        AROS_LCA(int,(__arg5),D2),
        struct DOpusBase *, (__DOpusBase), 59, DOpus    );
}

#define RawkeyToStr(arg1, arg2, arg3, arg4, arg5) \
    __inline_DOpus_RawkeyToStr((arg1), (arg2), (arg3), (arg4), (arg5), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_DoRMBGadget(struct RMBGadget* __arg1, struct Window* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, DoRMBGadget,
        AROS_LCA(struct RMBGadget*,(__arg1),A0),
        AROS_LCA(struct Window*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 60, DOpus    );
}

#define DoRMBGadget(arg1, arg2) \
    __inline_DOpus_DoRMBGadget((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_AddGadgets(struct Window* __arg1, struct Gadget* __arg2, char** __arg3, int __arg4, int __arg5, int __arg6, int __arg7, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC7(int, AddGadgets,
        AROS_LCA(struct Window*,(__arg1),A0),
        AROS_LCA(struct Gadget*,(__arg2),A1),
        AROS_LCA(char**,(__arg3),A2),
        AROS_LCA(int,(__arg4),D0),
        AROS_LCA(int,(__arg5),D1),
        AROS_LCA(int,(__arg6),D2),
        AROS_LCA(int,(__arg7),D3),
        struct DOpusBase *, (__DOpusBase), 61, DOpus    );
}

#define AddGadgets(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __inline_DOpus_AddGadgets((arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_ActivateStrGad(struct Gadget* __arg1, struct Window* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, ActivateStrGad,
        AROS_LCA(struct Gadget*,(__arg1),A0),
        AROS_LCA(struct Window*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 62, DOpus    );
}

#define ActivateStrGad(arg1, arg2) \
    __inline_DOpus_ActivateStrGad((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_RefreshStrGad(struct Gadget* __arg1, struct Window* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, RefreshStrGad,
        AROS_LCA(struct Gadget*,(__arg1),A0),
        AROS_LCA(struct Window*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 63, DOpus    );
}

#define RefreshStrGad(arg1, arg2) \
    __inline_DOpus_RefreshStrGad((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_CheckNumGad(struct Gadget* __arg1, struct Window* __arg2, int __arg3, int __arg4, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC4(int, CheckNumGad,
        AROS_LCA(struct Gadget*,(__arg1),A0),
        AROS_LCA(struct Window*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        AROS_LCA(int,(__arg4),D1),
        struct DOpusBase *, (__DOpusBase), 64, DOpus    );
}

#define CheckNumGad(arg1, arg2, arg3, arg4) \
    __inline_DOpus_CheckNumGad((arg1), (arg2), (arg3), (arg4), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_CheckHexGad(struct Gadget* __arg1, struct Window* __arg2, int __arg3, int __arg4, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC4(int, CheckHexGad,
        AROS_LCA(struct Gadget*,(__arg1),A0),
        AROS_LCA(struct Window*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        AROS_LCA(int,(__arg4),D1),
        struct DOpusBase *, (__DOpusBase), 65, DOpus    );
}

#define CheckHexGad(arg1, arg2, arg3, arg4) \
    __inline_DOpus_CheckHexGad((arg1), (arg2), (arg3), (arg4), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_Atoh(char* __arg1, int __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, Atoh,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        struct DOpusBase *, (__DOpusBase), 66, DOpus    );
}

#define Atoh(arg1, arg2) \
    __inline_DOpus_Atoh((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_HiliteGad(struct Gadget* __arg1, struct RastPort* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, HiliteGad,
        AROS_LCA(struct Gadget*,(__arg1),A0),
        AROS_LCA(struct RastPort*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 67, DOpus    );
}

#define HiliteGad(arg1, arg2) \
    __inline_DOpus_HiliteGad((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_DoSimpleRequest(struct Window* __arg1, struct DOpusSimpleRequest* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, DoSimpleRequest,
        AROS_LCA(struct Window*,(__arg1),A0),
        AROS_LCA(struct DOpusSimpleRequest*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 68, DOpus    );
}

#define DoSimpleRequest(arg1, arg2) \
    __inline_DOpus_DoSimpleRequest((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_ReadConfig(char* __arg1, struct ConfigStuff* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, ReadConfig,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(struct ConfigStuff*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 69, DOpus    );
}

#define ReadConfig(arg1, arg2) \
    __inline_DOpus_ReadConfig((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_SaveConfig(char* __arg1, struct ConfigStuff* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, SaveConfig,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(struct ConfigStuff*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 70, DOpus    );
}

#define SaveConfig(arg1, arg2) \
    __inline_DOpus_SaveConfig((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_DefaultConfig(struct ConfigStuff* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC1(int, DefaultConfig,
        AROS_LCA(struct ConfigStuff*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 71, DOpus    );
}

#define DefaultConfig(arg1) \
    __inline_DOpus_DefaultConfig((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_GetDevices(struct ConfigStuff* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC1(int, GetDevices,
        AROS_LCA(struct ConfigStuff*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 72, DOpus    );
}

#define GetDevices(arg1) \
    __inline_DOpus_GetDevices((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_AssignGadget(struct ConfigStuff* __arg1, int __arg2, int __arg3, const char* __arg4, const char* __arg5, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC5NR(void, AssignGadget,
        AROS_LCA(struct ConfigStuff*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        AROS_LCA(int,(__arg3),D1),
        AROS_LCA(const char*,(__arg4),A1),
        AROS_LCA(const char*,(__arg5),A2),
        struct DOpusBase *, (__DOpusBase), 73, DOpus    );
}

#define AssignGadget(arg1, arg2, arg3, arg4, arg5) \
    __inline_DOpus_AssignGadget((arg1), (arg2), (arg3), (arg4), (arg5), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_AssignMenu(struct ConfigStuff* __arg1, int __arg2, const char* __arg3, const char* __arg4, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC4NR(void, AssignMenu,
        AROS_LCA(struct ConfigStuff*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        AROS_LCA(const char*,(__arg3),A1),
        AROS_LCA(const char*,(__arg4),A2),
        struct DOpusBase *, (__DOpusBase), 74, DOpus    );
}

#define AssignMenu(arg1, arg2, arg3, arg4) \
    __inline_DOpus_AssignMenu((arg1), (arg2), (arg3), (arg4), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_FindSystemFile(char* __arg1, char* __arg2, int __arg3, int __arg4, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC4(int, FindSystemFile,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        AROS_LCA(int,(__arg4),D1),
        struct DOpusBase *, (__DOpusBase), 75, DOpus    );
}

#define FindSystemFile(arg1, arg2, arg3, arg4) \
    __inline_DOpus_FindSystemFile((arg1), (arg2), (arg3), (arg4), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_Do3DFrame(struct RastPort* __arg1, int __arg2, int __arg3, int __arg4, int __arg5, char* __arg6, int __arg7, int __arg8, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC8NR(void, Do3DFrame,
        AROS_LCA(struct RastPort*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        AROS_LCA(int,(__arg3),D1),
        AROS_LCA(int,(__arg4),D2),
        AROS_LCA(int,(__arg5),D3),
        AROS_LCA(char*,(__arg6),A1),
        AROS_LCA(int,(__arg7),D4),
        AROS_LCA(int,(__arg8),D5),
        struct DOpusBase *, (__DOpusBase), 76, DOpus    );
}

#define Do3DFrame(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) \
    __inline_DOpus_Do3DFrame((arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), (arg8), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_FreeConfig(struct ConfigStuff* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC1NR(void, FreeConfig,
        AROS_LCA(struct ConfigStuff*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 77, DOpus    );
}

#define FreeConfig(arg1) \
    __inline_DOpus_FreeConfig((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_DoCycleGadget(struct Gadget* __arg1, struct Window* __arg2, char** __arg3, int __arg4, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC4NR(void, DoCycleGadget,
        AROS_LCA(struct Gadget*,(__arg1),A0),
        AROS_LCA(struct Window*,(__arg2),A1),
        AROS_LCA(char**,(__arg3),A2),
        AROS_LCA(int,(__arg4),D0),
        struct DOpusBase *, (__DOpusBase), 78, DOpus    );
}

#define DoCycleGadget(arg1, arg2, arg3, arg4) \
    __inline_DOpus_DoCycleGadget((arg1), (arg2), (arg3), (arg4), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_UScoreText(struct RastPort* __arg1, char* __arg2, int __arg3, int __arg4, int __arg5, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC5NR(void, UScoreText,
        AROS_LCA(struct RastPort*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        AROS_LCA(int,(__arg4),D1),
        AROS_LCA(int,(__arg5),D2),
        struct DOpusBase *, (__DOpusBase), 79, DOpus    );
}

#define UScoreText(arg1, arg2, arg3, arg4, arg5) \
    __inline_DOpus_UScoreText((arg1), (arg2), (arg3), (arg4), (arg5), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_DisableGadget(struct Gadget* __arg1, struct RastPort* __arg2, int __arg3, int __arg4, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC4NR(void, DisableGadget,
        AROS_LCA(struct Gadget*,(__arg1),A0),
        AROS_LCA(struct RastPort*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        AROS_LCA(int,(__arg4),D1),
        struct DOpusBase *, (__DOpusBase), 80, DOpus    );
}

#define DisableGadget(arg1, arg2, arg3, arg4) \
    __inline_DOpus_DisableGadget((arg1), (arg2), (arg3), (arg4), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_EnableGadget(struct Gadget* __arg1, struct RastPort* __arg2, int __arg3, int __arg4, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC4NR(void, EnableGadget,
        AROS_LCA(struct Gadget*,(__arg1),A0),
        AROS_LCA(struct RastPort*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        AROS_LCA(int,(__arg4),D1),
        struct DOpusBase *, (__DOpusBase), 81, DOpus    );
}

#define EnableGadget(arg1, arg2, arg3, arg4) \
    __inline_DOpus_EnableGadget((arg1), (arg2), (arg3), (arg4), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_GhostGadget(struct Gadget* __arg1, struct RastPort* __arg2, int __arg3, int __arg4, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC4NR(void, GhostGadget,
        AROS_LCA(struct Gadget*,(__arg1),A0),
        AROS_LCA(struct RastPort*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        AROS_LCA(int,(__arg4),D1),
        struct DOpusBase *, (__DOpusBase), 82, DOpus    );
}

#define GhostGadget(arg1, arg2, arg3, arg4) \
    __inline_DOpus_GhostGadget((arg1), (arg2), (arg3), (arg4), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_DrawRadioButton(struct RastPort* __arg1, int __arg2, int __arg3, int __arg4, int __arg5, int __arg6, int __arg7, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC7NR(void, DrawRadioButton,
        AROS_LCA(struct RastPort*,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        AROS_LCA(int,(__arg3),D1),
        AROS_LCA(int,(__arg4),D2),
        AROS_LCA(int,(__arg5),D3),
        AROS_LCA(int,(__arg6),D4),
        AROS_LCA(int,(__arg7),D5),
        struct DOpusBase *, (__DOpusBase), 83, DOpus    );
}

#define DrawRadioButton(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __inline_DOpus_DrawRadioButton((arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline struct Image* __inline_DOpus_GetButtonImage(int __arg1, int __arg2, int __arg3, int __arg4, int __arg5, int __arg6, struct DOpusRemember** __arg7, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC7(struct Image*, GetButtonImage,
        AROS_LCA(int,(__arg1),D0),
        AROS_LCA(int,(__arg2),D1),
        AROS_LCA(int,(__arg3),D2),
        AROS_LCA(int,(__arg4),D3),
        AROS_LCA(int,(__arg5),D4),
        AROS_LCA(int,(__arg6),D5),
        AROS_LCA(struct DOpusRemember**,(__arg7),A0),
        struct DOpusBase *, (__DOpusBase), 84, DOpus    );
}

#define GetButtonImage(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __inline_DOpus_GetButtonImage((arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_ShowSlider(struct Window* __arg1, struct Gadget* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, ShowSlider,
        AROS_LCA(struct Window*,(__arg1),A0),
        AROS_LCA(struct Gadget*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 85, DOpus    );
}

#define ShowSlider(arg1, arg2) \
    __inline_DOpus_ShowSlider((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_CheckConfig(struct ConfigStuff* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC1(int, CheckConfig,
        AROS_LCA(struct ConfigStuff*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 86, DOpus    );
}

#define CheckConfig(arg1) \
    __inline_DOpus_CheckConfig((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline struct Image* __inline_DOpus_GetCheckImage(int __arg1, int __arg2, int __arg3, struct DOpusRemember** __arg4, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC4(struct Image*, GetCheckImage,
        AROS_LCA(int,(__arg1),D0),
        AROS_LCA(int,(__arg2),D1),
        AROS_LCA(int,(__arg3),D2),
        AROS_LCA(struct DOpusRemember**,(__arg4),A0),
        struct DOpusBase *, (__DOpusBase), 87, DOpus    );
}

#define GetCheckImage(arg1, arg2, arg3, arg4) \
    __inline_DOpus_GetCheckImage((arg1), (arg2), (arg3), (arg4), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline struct Window* __inline_DOpus_OpenRequester(struct RequesterBase* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC1(struct Window*, OpenRequester,
        AROS_LCA(struct RequesterBase*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 88, DOpus    );
}

#define OpenRequester(arg1) \
    __inline_DOpus_OpenRequester((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_CloseRequester(struct RequesterBase* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC1NR(void, CloseRequester,
        AROS_LCA(struct RequesterBase*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 89, DOpus    );
}

#define CloseRequester(arg1) \
    __inline_DOpus_CloseRequester((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline APTR __inline_DOpus_AddRequesterObject(struct RequesterBase* __arg1, struct TagItem* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(APTR, AddRequesterObject,
        AROS_LCA(struct RequesterBase*,(__arg1),A0),
        AROS_LCA(struct TagItem*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 90, DOpus    );
}

#define AddRequesterObject(arg1, arg2) \
    __inline_DOpus_AddRequesterObject((arg1), (arg2), __DOPUS_LIBBASE)

#if !defined(NO_INLINE_STDARG) && !defined(DOPUS_NO_INLINE_STDARG)
#define AddRequesterObjectTags(arg1, ...) \
({ \
    const IPTR AddRequesterObject_args[] = { AROS_PP_VARIADIC_CAST2IPTR(__VA_ARGS__) };\
    AddRequesterObject((arg1), (struct TagItem*)(AddRequesterObject_args)); \
})
#endif /* !NO_INLINE_STDARG */

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_RefreshRequesterObject(struct RequesterBase* __arg1, struct RequesterObject* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, RefreshRequesterObject,
        AROS_LCA(struct RequesterBase*,(__arg1),A0),
        AROS_LCA(struct RequesterObject*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 91, DOpus    );
}

#define RefreshRequesterObject(arg1, arg2) \
    __inline_DOpus_RefreshRequesterObject((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_ObjectText(struct RequesterBase* __arg1, short __arg2, short __arg3, short __arg4, short __arg5, char* __arg6, short __arg7, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC7NR(void, ObjectText,
        AROS_LCA(struct RequesterBase*,(__arg1),A0),
        AROS_LCA(short,(__arg2),D0),
        AROS_LCA(short,(__arg3),D1),
        AROS_LCA(short,(__arg4),D2),
        AROS_LCA(short,(__arg5),D3),
        AROS_LCA(char*,(__arg6),A1),
        AROS_LCA(short,(__arg7),D4),
        struct DOpusBase *, (__DOpusBase), 92, DOpus    );
}

#define ObjectText(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __inline_DOpus_ObjectText((arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_DoGlassImage(struct RastPort* __arg1, struct Gadget* __arg2, int __arg3, int __arg4, int __arg5, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC5NR(void, DoGlassImage,
        AROS_LCA(struct RastPort*,(__arg1),A0),
        AROS_LCA(struct Gadget*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        AROS_LCA(int,(__arg4),D1),
        AROS_LCA(int,(__arg5),D2),
        struct DOpusBase *, (__DOpusBase), 93, DOpus    );
}

#define DoGlassImage(arg1, arg2, arg3, arg4, arg5) \
    __inline_DOpus_DoGlassImage((arg1), (arg2), (arg3), (arg4), (arg5), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_Decode_RLE(char* __arg1, char* __arg2, int __arg3, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC3NR(void, Decode_RLE,
        AROS_LCA(char*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        struct DOpusBase *, (__DOpusBase), 94, DOpus    );
}

#define Decode_RLE(arg1, arg2, arg3) \
    __inline_DOpus_Decode_RLE((arg1), (arg2), (arg3), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_ReadStringFile(struct StringData* __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, ReadStringFile,
        AROS_LCA(struct StringData*,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 95, DOpus    );
}

#define ReadStringFile(arg1, arg2) \
    __inline_DOpus_ReadStringFile((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_FreeStringFile(struct StringData* __arg1, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC1NR(void, FreeStringFile,
        AROS_LCA(struct StringData*,(__arg1),A0),
        struct DOpusBase *, (__DOpusBase), 96, DOpus    );
}

#define FreeStringFile(arg1) \
    __inline_DOpus_FreeStringFile((arg1), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_LFreeRemEntry(struct DOpusRemember** __arg1, char* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, LFreeRemEntry,
        AROS_LCA(struct DOpusRemember**,(__arg1),A0),
        AROS_LCA(char*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 97, DOpus    );
}

#define LFreeRemEntry(arg1, arg2) \
    __inline_DOpus_LFreeRemEntry((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_AddGadgetBorders(struct DOpusRemember** __arg1, struct Gadget* __arg2, int __arg3, int __arg4, int __arg5, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC5NR(void, AddGadgetBorders,
        AROS_LCA(struct DOpusRemember**,(__arg1),A0),
        AROS_LCA(struct Gadget*,(__arg2),A1),
        AROS_LCA(int,(__arg3),D0),
        AROS_LCA(int,(__arg4),D1),
        AROS_LCA(int,(__arg5),D2),
        struct DOpusBase *, (__DOpusBase), 98, DOpus    );
}

#define AddGadgetBorders(arg1, arg2, arg3, arg4, arg5) \
    __inline_DOpus_AddGadgetBorders((arg1), (arg2), (arg3), (arg4), (arg5), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_CreateGadgetBorders(struct DOpusRemember** __arg1, int __arg2, int __arg3, struct Border** __arg4, struct Border** __arg5, int __arg6, int __arg7, int __arg8, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC8NR(void, CreateGadgetBorders,
        AROS_LCA(struct DOpusRemember**,(__arg1),A0),
        AROS_LCA(int,(__arg2),D0),
        AROS_LCA(int,(__arg3),D1),
        AROS_LCA(struct Border**,(__arg4),A1),
        AROS_LCA(struct Border**,(__arg5),A2),
        AROS_LCA(int,(__arg6),D2),
        AROS_LCA(int,(__arg7),D3),
        AROS_LCA(int,(__arg8),D4),
        struct DOpusBase *, (__DOpusBase), 99, DOpus    );
}

#define CreateGadgetBorders(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) \
    __inline_DOpus_CreateGadgetBorders((arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), (arg8), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline void __inline_DOpus_SelectGadget(struct Window* __arg1, struct Gadget* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    AROS_LC2NR(void, SelectGadget,
        AROS_LCA(struct Window*,(__arg1),A0),
        AROS_LCA(struct Gadget*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 100, DOpus    );
}

#define SelectGadget(arg1, arg2) \
    __inline_DOpus_SelectGadget((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

static inline int __inline_DOpus_FSSetMenuStrip(struct Window* __arg1, struct Menu* __arg2, APTR __DOpusBase)
{
    AROS_LIBREQ(DOpusBase, 22)
    return AROS_LC2(int, FSSetMenuStrip,
        AROS_LCA(struct Window*,(__arg1),A0),
        AROS_LCA(struct Menu*,(__arg2),A1),
        struct DOpusBase *, (__DOpusBase), 101, DOpus    );
}

#define FSSetMenuStrip(arg1, arg2) \
    __inline_DOpus_FSSetMenuStrip((arg1), (arg2), __DOPUS_LIBBASE)

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#endif /* INLINE_DOPUS_H*/
