#ifndef PROTO_DOPUS_H
#define PROTO_DOPUS_H

/*
    *** Automatically generated from '/home/vsts/work/1/s/contrib/dopus/Library/dopus.conf'. Edits will be lost. ***
    Copyright (C) 1995-2025, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/dopus_protos.h>

#ifndef __DOPUS_RELLIBBASE__
 #if !defined(__NOLIBBASE__) && !defined(__DOPUS_NOLIBBASE__)
  #if !defined(DOpusBase)
   #ifdef __DOPUS_STDLIBBASE__
    extern struct Library *DOpusBase;
   #else
    extern struct DOpusBase *DOpusBase;
   #endif
  #endif
  #ifndef __aros_getbase_DOpusBase
   #define __aros_getbase_DOpusBase() (DOpusBase)
  #endif
 #endif /* defined(__NOLIBBASE__) || defined(__DUMMY_NOLIBBASE__) */
#else /* __DOPUS_RELLIBASE__ */
 extern const IPTR __aros_rellib_offset_DOpusBase;
 #define AROS_RELLIB_OFFSET_DOPUS __aros_rellib_offset_DOpusBase
 #define AROS_RELLIB_BASE_DOPUS __aros_rellib_base_DOpusBase
 #ifndef __aros_getbase_DOpusBase
  #ifndef __aros_getoffsettable
   char *__aros_getoffsettable(void);
  #endif
  #define __aros_getbase_DOpusBase() (*(struct DOpusBase **)(__aros_getoffsettable()+__aros_rellib_offset_DOpusBase))
 #endif
#endif

#ifndef __aros_getbase_DOpusBase
extern struct DOpusBase *__aros_getbase_DOpusBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(DOPUS_NOLIBINLINE) && !defined(__DOPUS_RELLIBBASE__)
# include <inline/dopus.h>
#elif !defined(NOLIBDEFINES) && !defined(DOPUS_NOLIBDEFINES)
# include <defines/dopus.h>
#endif

#endif /* PROTO_DOPUS_H */
